﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tng.TechnicalEvaluation.Infrastructure.Services;

namespace Tng.TechnicalEvaluation.Services
{
    public class SortService : ISortService
    {
        public string BubbleSort(string input)
        {
            //TODO - Complete this
            input = String.Join<string>(",", BubbleSortAlgorithm(input.Split(',').ToList()));
            return input;
        }

        public string SelectSort(string input)
        {
            //TODO - Complete this
            input = String.Join<string>(",", SelectSortAlgorithm(input.Split(',').ToList())); ;
            return input;
        }
        private List<string> SelectSortAlgorithm(List<string> inputList)
        {
            List<string> result = inputList;
            for(int i = 0; i < result.Capacity - 1 ; i++)
            {
                if (string.Compare(result[i], result[i + 1]) > 0) 
                {
                    var temp = result[i];
                    result[i] = result[i + 1];
                    result[i + 1] = temp;
                }
            }
            return result;
        }
        private List<string> BubbleSortAlgorithm(List<string> inputList)
        {
            List<string> result = inputList;
            for (int i = 0; i < result.Capacity - 1; i++)
            {
                if (string.Compare(result[i], result[i + 1]) < 0)
                {
                    var temp = result[i];
                    result[i] = result[i + 1];
                    result[i + 1] = temp;
                }
            }
            return result;
        }
    }
}